To run, run the python files for each of the toy problems. Run the Python notebooks afterwards to generate graphs.
