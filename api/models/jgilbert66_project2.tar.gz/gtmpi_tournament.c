#include <stdlib.h>
#include <stdio.h>
#include <mpi.h>
#include "gtmpi.h"
#include <math.h>
/***********************NOTE************************/
//Requires math compiler flag

/*
    From the MCS Paper: A scalable, distributed tournament barrier with only local spinning

    type round_t = record
        role : (winner, loser, bye, champion, dropout)
	opponent_rnk : ^Boolean
	flag : Boolean
    shared rounds : array [0..P-1][0..LogP] of round_t
        // row vpid of rounds is allocated in shared memory
	// locally accessible to processor vpid

    processor private sense : Boolean := true
    processor private vpid : integer // a unique virtual processor index

    //initially
    //    rounds[i][k].flag = false for all i,k
    //rounds[i][k].role = 
    //    winner if k > 0, i mod 2^k = 0, i + 2^(k-1) < P , and 2^k < P
    //    bye if k > 0, i mode 2^k = 0, and i + 2^(k-1) >= P
    //    loser if k > 0 and i mode 2^k = 2^(k-1)
    //    champion if k > 0, i = 0, and 2^k >= P
    //    dropout if k = 0
    //    unused otherwise; value immaterial
    //rounds[i][k].opponent_rnk points to 
    //    round[i-2^(k-1)][k].flag if rounds[i][k].role = loser
    //    round[i+2^(k-1)][k].flag if rounds[i][k].role = winner or champion
    //    unused otherwise; value immaterial
    procedure tournament_barrier
        round : integer := 1
	loop   //arrival
	    case rounds[vpid][round].role of
	        loser:
	            rounds[vpid][round].opponent_rnk^ :=  sense
		    repeat until rounds[vpid][round].flag = sense
		    exit loop
   	        winner:
	            repeat until rounds[vpid][round].flag = sense
		bye:  //do nothing
		champion:
	            repeat until rounds[vpid][round].flag = sense
		    rounds[vpid][round].opponent_rnk^ := sense
		    exit loop
		dropout: // impossible
	    round := round + 1
	loop  // wakeup
	    round := round - 1
	    case rounds[vpid][round].role of
	        loser: // impossible
		winner:
		    rounds[vpid[round].opponent_rnk^ := sense
		bye: // do nothing
		champion: // impossible
		dropout:
		    exit loop
	sense := not sense
*/

/***************ALGORITHM**********************/
//Instead of the above pseudocode, I used the psuedocode in A Survey of Barrier Algorithms for Coarse Grained Supercomputers by Hoefler et al.
//The paper can be found at :https://www.researchgate.net/profile/Torsten_Hoefler/publication/229019601_A_Survey_of_Barrier_Algorithms_for_Coarse_Grained_Supercomputers_Chemnitzer_Informatik_Berichte/links/0a85e52f67a60b9e5b000000/A-Survey-of-Barrier-Algorithms-for-Coarse-Grained-Supercomputers-Chemnitzer-Informatik-Berichte.pdf





void gtmpi_init(int num_threads) {
	//procs = num_threads;
	//globalsense = 0;
}

void gtmpi_barrier() {
	int rank;
	int procs;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &procs);
	int rounds = (int) (log(procs) / log(2.0));
	int roundnum = -1;
	while (roundnum < rounds) {
		roundnum = roundnum + 1;
		int opponent_rnk = (rank ^ ((int) pow(2.0, roundnum)));
		//printf("2 to the roundnum is %d \n", (int) pow(2, roundnum));
		if (opponent_rnk > procs - 1) {
			//bye! not a true participant this round
			//printf("Process %d has no opponent_rnk in round %d, potential opponent_rnk was %d \n", rank, rnd, opponent_rnk);
			//printf("*****P%d is NOT participant in round %d***** \n", rank, roundnum + 1);
			continue;
		}
		if (rank > opponent_rnk) {
			//this process is the "winner", it can proceed as soon as the loser lets it know of its arrival

			//MPI_Request req = MPI_REQUEST_NULL;
			//printf("*****P%d is a participant in round %d***** \n", rank, roundnum + 1);
			//printf("OPPONENT RANK ENCOUNTERED BY %d IS %d ON ROUND %d \n", opponent_rnk, rank, roundnum);
			MPI_Recv(NULL, 0, MPI_INT, opponent_rnk, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
			//MPI_Send(NULL, 0, MPI_INT, opponent_rnk, 1, MPI_COMM_WORLD);
			//MPI_Recv(NULL, 0, MPI_INT, opponent_rnk, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
			//MPI_Wait(&req, MPI_STATUS_IGNORE);
			//MPI_Request_free(&req);
		} else {
			//this process is the loser and attempts to handshake with the winner of its round
			//printf("*****P%d is a participant in round %d***** \n", rank, roundnum + 1);
			MPI_Ssend(NULL, 0, MPI_INT, opponent_rnk, 1, MPI_COMM_WORLD);
			//MPI_Recv(NULL, 0, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

			//printf("Process %d congratulates process %d in round %d \n", rank, opponent_rnk, round);


		}


	}


	if (rank == 0) {
		//clock_t  timit =clock();
		//printf("Rank %d reached barrier at time %d \n",rank,(int)timit);
		//this is the "champion" process
		if (procs > 1) {
			MPI_Request req;
			for (int p = 1; p < procs; p++) {
				MPI_Isend(NULL, 0, MPI_INT, p, 0, MPI_COMM_WORLD, &req);
			}
			MPI_Request_free(&req);
		}
	} else {
		MPI_Recv(NULL, 0, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

	}


}

void gtmpi_finalize() {

}
