#include <stdlib.h>
#include <stdio.h>
#include <omp.h>
#include "gtmp.h"
#include <string.h>
#include <math.h>
/***********************NOTE************************/
//Requires math compiler flag

/*
    From the MCS Paper: A scalable, distributed tree-based barrier with only local spinning.

    type treenode = record
        parentsense : Boolean
	parentpointer : ^Boolean
	childpointers : array [0..1] of ^Boolean
	havechild : array [0..3] of Boolean
	childnotready : array [0..3] of Boolean
	dummy : Boolean //pseudo-data

    shared nodes : array [0..P-1] of treenode
        // nodes[vpid] is allocated in shared memory
        // locally accessible to processor vpid
    processor private vpid : integer // a unique virtual processor index
    processor private sense : Boolean

    // on processor i, sense is initially true
    // in nodes[i]:
    //    havechild[j] = true if 4 * i + j + 1 < P; otherwise false
    //    parentpointer = &nodes[floor((i-1)/4].childnotready[(i-1) mod 4],
    //        or dummy if i = 0
    //    childpointers[0] = &nodes[2*i+1].parentsense, or &dummy if 2*i+1 >= P
    //    childpointers[1] = &nodes[2*i+2].parentsense, or &dummy if 2*i+2 >= P
    //    initially childnotready = havechild and parentsense = false
	
    procedure tree_barrier
        with nodes[vpid] do
	    repeat until childnotready = {false, false, false, false}
	    childnotready := havechild //prepare for next barrier
	    parentpointer^ := false //let parent know I'm ready
	    // if not root, wait until my parent signals wakeup
	    if vpid != 0
	        repeat until parentsense = sense
	    // signal children in wakeup tree
	    childpointers[0]^ := sense
	    childpointers[1]^ := sense
	    sense := not sense
*/


/*typedef struct thread_priv {
	int localsense;
	int vpid;
} thread_priv;
 */
//int **private_sense;

//typedef struct tree_node tree_node;

typedef struct tree_node {
	int *parent_pointer;
	int *children[2];
	int havechild[4];
	int childNOTready[4];
	int parent_sense;
	int dummy;
	//char pad[LEVEL1_DCACHE_LINESIZE];
	/*type treenode = record
	parentsense : Boolean
	parentpointer : ^Boolean
	childpointers : array [0..1] of ^Boolean
	havechild : array [0..3] of Boolean
	childnotready : array [0..3] of Boolean
	dummy : Boolean //pseudo-data*/

} tree_node;


tree_node *nodes_sh;
int **private_sense;
int nthreads;

void gtmp_init(int num_threads) {

	nthreads = num_threads;
	printf("Size of struct is %d \n", (int) sizeof(struct tree_node));
	//nodes array
	private_sense = (int **) malloc(sizeof(int *) * nthreads);
	memset(private_sense, 0, sizeof(int *) * nthreads);
	for (int i = 0; i < nthreads; i++) {
		size_t sizeit = LEVEL1_DCACHE_LINESIZE - sizeof(struct tree_node);
		if (sizeit < sizeof(struct tree_node)) {
			sizeit = sizeof(struct tree_node);
		}
		//size_t sizeit = (sizeof(struct tree_node) >= (LEVEL1_DCACHE_LINESIZE-sizeof(struct tree_node))) ? sizeof(struct tree_node) : LEVEL1_DCACHE_LINESIZE-sizeof(struct tree_node);
		posix_memalign((void *) &private_sense[i], LEVEL1_DCACHE_LINESIZE, sizeit);
		//memset(private_sense[i], 0, sizeof(int) * LEVEL1_DCACHE_LINESIZE);

	}

	for (int i = 0; i < nthreads; i++) {
		private_sense[i][0] = 1;
	}


	//nodes_sh = malloc(sizeof(struct tree_node) * nthreads);
	posix_memalign((void *) &nodes_sh, LEVEL1_DCACHE_LINESIZE, sizeof(struct tree_node) * nthreads);

	//memset(nodes_sh, 0, sizeof(struct tree_node) * nthreads);
	//private_data = calloc((size_t) nthreads, sizeof(int));
	for (int cn = 0; cn < nthreads; cn++) {
		//nodes_sh[cn].sense = 1;
		nodes_sh[cn].parent_sense = 0;
	}
	for (int i = 0; i < nthreads; i++) {
		for (int j = 0; j < 4; j++) {

			int child = (4 * i + j + 1);
			if (child < nthreads) {
				nodes_sh[i].havechild[j] = 1;
			} else {
				nodes_sh[i].havechild[j] = 0;
			}
		}
		if (i != 0) {
			(nodes_sh[i].parent_pointer) = &nodes_sh[(i - 1) / 4].childNOTready[(i - 1) % 4];
		} else {
			(nodes_sh[i].parent_pointer) = &nodes_sh[i].dummy;
		}

		nodes_sh[i].children[0] = (2 * i + 1) < nthreads ? &nodes_sh[2 * i + 1].parent_sense : &nodes_sh[i].dummy;
		nodes_sh[i].children[1] = (2 * i + 2) < nthreads ? &nodes_sh[2 * i + 2].parent_sense : &nodes_sh[i].dummy;
		//nodes_sh[i].childNOTready = nodes_sh[i].havechild;
		for (int cn = 0; cn < 4; cn++) {
			nodes_sh[i].childNOTready[cn] = nodes_sh[i].havechild[cn];
		}

	}
}


/*shared nodes : array [0..P-1] of treenode
// nodes[vpid] is allocated in shared memory
// locally accessible to processor vpid */



void gtmp_barrier() {
	int id = omp_get_thread_num();
	//printf("thread %d started \n", id);
	//private_data[id].vpid = id;
	//tree_node curnode = nodes_sh[id];
	int loop = 1;
	do {
		int seen = 0;
		for (int k = 0; k < 4; k++) {
			if (nodes_sh[id].childNOTready[k] == 1) {
				seen = 1;
			}

		}
		if (seen == 1) {
			loop = 1;
		} else { loop = 0; }
		//printf("thread %d looped \n", id);

	} while (loop);

	//repeat until childNotReady
	//while ((nodes_sh[id].childNOTready[0] | nodes_sh[id].childNOTready[1] | nodes_sh[id].childNOTready[2] |
	//        nodes_sh[id].childNOTready[3]));
//

	//set parent pointer to False (I'm read)
	//
	*(nodes_sh[id].parent_pointer) = 0;

	for (int chn = 0; chn < 4; chn++) {
		nodes_sh[id].childNOTready[chn] = nodes_sh[id].havechild[chn];
	}

	//printf("thread %d set parent pointer at %p \n", id, &(nodes_sh[id].parent_pointer));
	if (id != 0) {

		while (nodes_sh[id].parent_sense != private_sense[id][0]);//nodes_sh[id].sense);

		//printf("thread %d got past sense \n", id);

	}

	*nodes_sh[id].children[0] = *nodes_sh[id].children[1] = __sync_fetch_and_xor(&private_sense[id][0], 1);
	//nodes_sh[id].sense = nodes_sh[id].sense ^ 1;


/*    procedure tree_barrier
        with nodes[vpid] do
	    repeat until childnotready = {false, false, false, false}
	    childnotready := havechild //prepare for next barrier
	    parentpointer^ := false //let parent know I'm ready
	    // if not root, wait until my parent signals wakeup
	    if vpid != 0
	        repeat until parentsense = sense
	    // signal children in wakeup tree
	    childpointers[0]^ := sense
	    childpointers[1]^ := sense
	    sense := not sense*/
}

void gtmp_finalize() {
	free(nodes_sh);
	for (int i = 0; i < nthreads; i++) {
		free(private_sense[i]);
	}
	free(private_sense);
}
