#include <stdlib.h>
#include <mpi.h>
#include <stdio.h>
#include "gtmpi.h"



/*
    From the MCS Paper: A sense-reversing centralized barrier

    shared count : integer := P
    shared sense : Boolean := true
    processor private local_sense : Boolean := true

    procedure central_barrier
        local_sense := not local_sense // each processor toggles its own sense
	if fetch_and_decrement (&count) = 1
	    count := P
	    sense := local_sense // last processor toggles global sense
    else
        repeat until sense = local_sense
*/


/******************* OPTIMIZATIONS *********************/

//1. No "shared" array with status array, the macro MPI_STATUS_IGNORE is used so we don't have to allocate any statuses
//2. This is the "centralized counter" version as described by the psuedocode in A Survey of Barrier Algorithms for Coarse
//  Grained Supercomputers by Hoefler et al.
//3. Instead of requiring matching send/receives for every process, only one process keeps track of the sends.
//4. It then sends a message with a different tag with guaranteed no-blocking behavior. Using a different tag for the wakeup message
//   appeared to improve performance.
//5. Since there is no need for every process to send a message to every other process, this reduces communication

void gtmpi_init(int num_threads) {
	//P = num_threads;
	//status_array = (MPI_Status *) malloc((P - 1) * sizeof(MPI_Status));
	//sense = 1;
}

void gtmpi_barrier() {
	//using the centralized counter algorithm
	//MPI_Recv(NULL, 0, MPI_INT, vpid, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

	//setbuf(stderr,NULL);
	int maxrank;
	MPI_Comm_size(MPI_COMM_WORLD, &maxrank);

	int vpid;

	//fflush(stderr);

	MPI_Comm_rank(MPI_COMM_WORLD, &vpid);



	//MPI_Status sense = status_array[vpid];
	if (vpid == maxrank - 1) {
		for (int i = 0; i < maxrank - 1; i++) {
			MPI_Status probe;
			//MPI_Status probe;
			//receive "barrier reached" status from all other threads, block f
			MPI_Probe(i, 0, MPI_COMM_WORLD, &probe);

			MPI_Recv(NULL, 0, MPI_C_BOOL, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
			//MPI_Probe(i, 0, MPI_COMM_WORLD, &probe);
		}
		//fprintf(stderr, "Central counter has received all of the notifications \n");
		//fflush(stderr);
		for (int i = 0; i <= maxrank - 1; i++) {
			MPI_Request localsense = MPI_REQUEST_NULL;
			//central counter pings each of the waiting processes, all other processes have been heard from
			MPI_Isend(NULL, 0, MPI_C_BOOL, i, 1, MPI_COMM_WORLD, &localsense);
			MPI_Request_free(&localsense);
		}
	} else {
		//let the fixed last rank process get signalled
		//MPI_Request localsense = MPI_REQUEST_NULL;
		MPI_Send(NULL, 0, MPI_C_BOOL, maxrank - 1, 0, MPI_COMM_WORLD);//, &localsense);
		//MPI_Request_free(&localsense);
		//MPI_Send(NULL, 0, MPI_INT, P - 1, 1, MPI_COMM_WORLD);
		MPI_Status probe;
		//MPI_Request req;
		//int flag = 0;

		MPI_Probe(maxrank - 1, 1, MPI_COMM_WORLD, &probe);
		//fprintf(stderr,"VPID %d got a green light to move forward \n", vpid);
		//fflush(stderr);
		MPI_Recv(NULL, 0, MPI_C_BOOL, maxrank - 1, 1, MPI_COMM_WORLD, &probe);

		//MPI_Wait(&probe);
	}

	//we're waiting to receive a message from the central counter
	//fflush(stderr);

	//MPI_Wait(NULL,&probe);
}


void gtmpi_finalize() {
	//if (status_array != NULL) {
	//	free(status_array);
	//}
}

