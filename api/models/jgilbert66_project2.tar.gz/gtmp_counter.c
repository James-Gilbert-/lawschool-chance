#include <omp.h>
#include <stdlib.h>
#include "gtmp.h"
#include <string.h>
#include <stdio.h>

/*
    From the MCS Paper: A sense-reversing centralized barrier

    shared count : integer := P
    shared sense : Boolean := true
    processor private local_sense : Boolean := true

    procedure central_barrier
        local_sense := not local_sense // each processor toggles its own sense
	if fetch_and_decrement (&count) = 1
	    count := P
	    sense := local_sense // last processor toggles global sense
        else
           repeat until sense = local_sense
*/


int count_sh;
int sense_sh;
int nthreads;
int **private_sense;


void gtmp_init(int num_threads) {
	nthreads = num_threads;
	count_sh = num_threads;
	sense_sh = 1;
	private_sense = malloc(sizeof(int *) * nthreads);
	memset(private_sense, 0, sizeof(int *) * nthreads);

	for (int i = 0; i < nthreads; i++) {
		//printf("Cache size is %d \n",LEVEL1_DCACHE_LINESIZE);
		//private_sense[i] =(int *) malloc(sizeof(int));
		posix_memalign((void *) &private_sense[i], LEVEL1_DCACHE_LINESIZE, (size_t) sizeof(int));

	}
	for (int i = 0; i < nthreads; i++) {
		private_sense[i][0] = 1;
	}
	//int private_sense_test[num_threads][LEVEL1_DCACHE_LINESIZE];


	//*private_sense=&private_sense_test;
}

void gtmp_barrier() {
	int id = omp_get_thread_num();
	//int id = __sync_fetch_and_add(&arrival, 1);
	private_sense[id][0] = private_sense[id][0] ^ 1;
	int test_count;
	test_count = __sync_fetch_and_sub(&count_sh, 1);
	//no need to continuously spin on the test count on the shared variable
	int cachesense = private_sense[id][0];
	if (test_count != 1) {
		//do the typical case
		while (sense_sh != cachesense);

	} else {
	//if last, reset count to the number of threads, reverse/toggle sense
		count_sh = nthreads;
		sense_sh = cachesense;
	}


}

void gtmp_finalize() {
	for (int i = 0; i < nthreads; i++) {
		free(private_sense[i]);
	}
	free(private_sense);
}
