#include <stdlib.h>
#include <stdio.h>
#include <omp.h>
#include <string.h>
#include "gtmp.h"

/*

    From the MCS Paper: A software combining tree barrier with optimized wakeup

    type node = record
        k : integer //fan in of this node
	count : integer // initialized to k
	locksense : Boolean // initially false
	parent : ^node // pointer to parent node; nil if root

	shared nodes : array [0..P-1] of node
	    //each element of nodes allocated in a different memory module or cache line

	processor private sense : Boolean := true
	processor private mynode : ^node // my group's leaf in the combining tree 

	procedure combining_barrier
	    combining_barrier_aux (mynode) // join the barrier
	    sense := not sense             // for next barrier
	    

	procedure combining_barrier_aux (nodepointer : ^node)
	    with nodepointer^ do
	        if fetch_and_decrement (&count) = 1 // last one to reach this node
		    if parent != nil
		        combining_barrier_aux (parent)
		    count := k // prepare for next barrier
		    locksense := not locksense // release waiting processors
		repeat until locksense = sense
*/

/************************OPTIMIZATIONS***********************/
//Created a 2d array that pads each of the elements so that they sit on their own cacheline, avoiding false sharing
//Fixed the case in which the barrier is called with a single thread
//Instead of using pragma critical, an atomic fetch and sub operation is used

typedef struct _node_t {
	int k;
	int count;
	int locksense;
	struct _node_t *parent;

} node_t;

int num_leaves;
node_t **nodes;

void gtmp_barrier_aux(node_t *node, int sense);

node_t *_gtmp_get_node(int i) {
	//printf("got node %d \n", i);
	return &nodes[i][0];
}

void gtmp_init(int num_threads) {
	int num_nodes;
	//node_t* curnode;

	/*Setting constants */
	int v = 1;
	while (v < num_threads)
		v *= 2;

	num_nodes = v - 1;
	num_leaves = v / 2;




	/* Setting up the tree */
	//int size = LEVEL1_DCACHE_LINESIZE;
	if (num_leaves > 0) {
		nodes = (node_t **) malloc(sizeof(node_t *) * num_nodes);
		for (int i = 0; i < num_nodes; i++) {
			//nodes[i] = (node_t *) malloc(sizeof(node_t) + LEVEL1_DCACHE_LINESIZE);
			//nodes[i] = (node_t *)malloc(sizeof(node_t)*LEVEL1_DCACHE_LINESIZE/8);
			//posix_memalign((void *)&nodes[i],LEVEL1_DCACHE_LINESIZE/8,sizeof(node_t));
			posix_memalign((void *) &nodes[i], LEVEL1_DCACHE_LINESIZE, (size_t) sizeof(int));

		}

		//memset(nodes,0,num_nodes * sizeof(node_t));
		for (int i = 0; i < num_nodes; i++) {
			node_t *curnode = NULL;
			curnode = _gtmp_get_node(i);
			//printf("Got node %d \n", i);
			curnode[0].k = i < num_threads - 1 ? 2 : 1;
			curnode[0].count = curnode->k;
			curnode[0].locksense = 0;
			curnode[0].parent = _gtmp_get_node((i - 1) / 2);
		}


		_gtmp_get_node(0)[0].parent = NULL;
		//printf("got here \n");
		//curnode->parent = NULL;
	}

}

void gtmp_barrier() {

	if (num_leaves > 0) {

		node_t *mynode = _gtmp_get_node(num_leaves - 1 + (omp_get_thread_num() % num_leaves));

		/*
		   Rather than correct the sense variable after the call to
		   the auxilliary method, we set it correctly before.
		 */
		int sense = !mynode->locksense;

		gtmp_barrier_aux(mynode, sense);
	}
}

void gtmp_barrier_aux(node_t *node, int sense) {
	//int test;

	//we actually don't need a pragma here
/*
#pragma omp critical
	{
		test = node->count;
		node->count--;
	}
*/
	//printf("reached barrier \n");
	int test = __sync_fetch_and_sub(&node->count, 1);

	if (test == 1) {
		if (node->parent != NULL)
			gtmp_barrier_aux(node->parent, sense);
		node->count = node->k;
		(node->locksense) ^= 1;// !node->locksense;
	}
	while (node->locksense != sense);
}

void gtmp_finalize() {
	if (num_leaves > 0)
		free(nodes);
}
