#include <stdlib.h>
#include <stdio.h>
#include <mpi.h>
#include "gtmpi.h"
#include <math.h>
#include <memory.h>

/***********************NOTE************************/
//Requires math compiler flag


/*
    From the MCS Paper: The scalable, distributed dissemination barrier with only local spinning.

    type flags = record
        myflags : array [0..1] of array [0..LogP - 1] of Boolean
	partnerflags : array [0..1] of array [0..LogP - 1] of ^Boolean
	
    processor private parity : integer := 0
    processor private sense : Boolean := true
    processor private localflags : ^flags

    shared allnodes : array [0..P-1] of flags
        //allnodes[i] is allocated in shared memory
	//locally accessible to processor i

    //on processor i, localflags points to allnodes[i]
    //initially allnodes[i].myflags[r][k] is false for all i, r, k
    //if j = (i+2^k) mod P, then for r = 0 , 1:
    //    allnodes[i].partnerflags[r][k] points to allnodes[j].myflags[r][k]

    procedure dissemination_barrier
        for instance : integer :0 to LogP-1
	    localflags^.partnerflags[parity][instance]^ := sense
	    repeat until localflags^.myflags[parity][instance] = sense
	if parity = 1
	    sense := not sense
	parity := 1 - parity
*/

static int procs;
static int rounds;
//static MPI_Status *status_array;
int **recvs;

void gtmpi_init(int num_threads) {


	procs = num_threads;
	double base = (1.0 * log(procs)) / log(2.0);
	rounds = (int) ceil(base);

	recvs = (int **) malloc(sizeof(int *) * num_threads);
	//memset(recvs,0,sizeof(int *) * num_threads);

	for (int i = 0; i < num_threads; i++) {
		recvs[i] = (int *) malloc(sizeof(int) * rounds);
		//memset(recvs[i],0,sizeof(int ) * rounds);
	}


	//printf("Rounds are %d \n", rounds);
	for (int rnk = 0; rnk < num_threads; rnk++) {
		for (int rnd = 0; rnd < rounds; rnd++) {
			for (int i = 0; i < procs; i++) {
				int receive = (int) (i + pow(2.0, rnd)) % procs;
				if (receive == rnk) {
					recvs[rnk][rnd] = i;
					//printf("rank %d receives from %d", rank, i);
				}
			}
		}
	}

}

void gtmpi_barrier() {
	int rank;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	//the signals need not happen at the same time
	//the sends should be asynchronous, but this should be blocked on receives
	//int recvs[rounds];


	for (int round_n = 0; round_n < rounds; round_n++) {


		//MPI_Request localsense = MPI_REQUEST_NULL;
		int send_to = (int) (rank + pow(2.0, round_n)) % procs;
		MPI_Send(NULL, 0, MPI_INT, send_to, 1, MPI_COMM_WORLD);
		MPI_Recv(NULL, 0, MPI_INT, recvs[rank][round_n], 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);// &localsense);


/*for (int p = 0;p < procs;p++) {
			int receive_from = (int) (p + pow(2.0, round)) % procs;
			if (receive_from == rank) {
//printf("Proc %d waiting to hear from rank %d on round %d\n", rank, receive_from, round);}
		}*/



		//MPI_Request_free(&localsense);
	}





/*
for (int round = 0; round < rounds; round++) {
	//MPI_Request localsense = MPI_REQUEST_NULL;
	//int send_to = (int) (rank + pow(2.0, round)) % procs;
	//
	//MPI_Ssend(NULL, 0, MPI_INT, send_to, 1, MPI_COMM_WORLD);
	//MPI_Recv(NULL, 0, MPI_INT, (int) send_to, 1, MPI_COMM_WORLD, &localsense);
	//MPI_Request_free(&localsense);
}

*/


/*MPI_Request localsense = MPI_REQUEST_NULL;
MPI_Isend(NULL, 0, MPI_INT, P - 1, 1, MPI_COMM_WORLD, &localsense);
MPI_Request_free(&localsense);*/







}

void gtmpi_finalize() {
	for (int i = 0; i < procs; i++) {
		free(recvs[i]);
	}
	free(recvs);
}
